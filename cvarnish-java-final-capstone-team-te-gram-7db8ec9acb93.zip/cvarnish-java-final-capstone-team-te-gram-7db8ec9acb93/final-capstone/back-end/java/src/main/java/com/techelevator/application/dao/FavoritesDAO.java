package com.techelevator.application.dao;

import java.util.List;

import com.techelevator.application.model.Favorites;

public interface FavoritesDAO {
      void create(int photoId, int userId);
      
      List<Favorites>getAllByUserId(int userId);
      void delete(int userId, int photoId);
}
