package com.techelevator.application.jdbcdao;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Service;

import com.techelevator.application.dao.PhotosDAO;
import com.techelevator.application.model.Favorites;
import com.techelevator.application.model.Photos;
@Service
public class PhotosJDBCDAO implements PhotosDAO {
	private JdbcTemplate jdbcTemplate;
	
	public PhotosJDBCDAO (JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	//@Override
	/*
	 * public Photos create(long photoId, String caption, String url, LocalDate
	 * dateAdded, LocalTime timeAdded, int userId) { String addNewPhoto =
	 * "insert into photos" +
	 * "(photo_id, caption, url, date_added, time_added, user_id )" +
	 * "values(?,?,?,?,?,?)";
	 * 
	 * return null; }
	 */
	@Override
	public void create(Photos newPhoto, int userId) {
		LocalTime currentTime = LocalTime.now();
		LocalDate currentDate = LocalDate.now();
		String addNewPhoto = "insert into photos "
				             + "(photo_id, caption, url, date_added, time_added, user_id, likes) "
				             + "values(?,?,?,?,?,?,?)";
		newPhoto.setPhotoId(getNextPhotoId());
		newPhoto.setTimeAdded(currentTime);
		newPhoto.setDateAdded(currentDate);
		newPhoto.setUserId(userId);
		newPhoto.setLikes(0);
		jdbcTemplate.update(addNewPhoto,newPhoto.getPhotoId(),newPhoto.getCaption(),newPhoto.getUrl(),newPhoto.getDateAdded(),newPhoto.getTimeAdded(),newPhoto.getUserId(), newPhoto.getLikes());
		//return newPhoto;
	}
	
	@Override
	public List<Photos> getbyUserId(Long userid) {
		List<Photos> photosLists = new ArrayList();
		
		String sqlPhotosList = "select * "
				               + "from photos "
				               + "inner join users "
				               +"ON photos.user_id = users.user_id "
				               + "where photos.user_id = ?";
		SqlRowSet photoQuery = jdbcTemplate.queryForRowSet(sqlPhotosList,userid);
		while(photoQuery.next()) {
			Photos thePhoto =  mapRowToPhoto(photoQuery);
			photosLists.add(thePhoto);
		}
		
		
		return photosLists;
	}

	@Override
	public List<Photos> getbyDate() {
		List<Photos> photosListsByDate = new ArrayList();
		String sqlPhotoByDate = "select * "
				                + " from photos "
					            + "inner join users "
					            +"ON photos.user_id = users.user_id "
				                + " order by date_added desc";
		SqlRowSet photoDateQuery = jdbcTemplate.queryForRowSet(sqlPhotoByDate);
		while(photoDateQuery.next()) {
			Photos thePhotoByDate = mapRowToPhoto(photoDateQuery);
			photosListsByDate.add(thePhotoByDate);
		}
		
		return photosListsByDate;
	}

	@Override
	public List<Photos> getAll() {
		List<Photos> photosLists = new ArrayList();
		
		String sqlPhotosLists = "select * "
				                + " from photos "
				                + "inner join users "
				                + "ON photos.user_id = users.user_id "
				                + " order by date_added, time_added desc";
		SqlRowSet photoListAll = jdbcTemplate.queryForRowSet(sqlPhotosLists);
		while(photoListAll.next()) {
			Photos thePhotosList = mapRowToPhoto(photoListAll);
			photosLists.add(thePhotosList);
		}
				                
		
		return photosLists;
	}
	
	
	@Override
	
	public List<Photos> getFavorites(int userId) {
		List<Photos> favoritesList = new ArrayList();
		
		String sqlFavoritesLists = "select * "
								+ "from photos "
					            + "inner join users "
					            +"ON photos.user_id = users.user_id "
								+ "where user_id = ? ";
								
								
		SqlRowSet favoritesListAll = jdbcTemplate.queryForRowSet(sqlFavoritesLists, userId);
		while(favoritesListAll.next()) {
			Photos theFavoritesList = mapRowToPhoto(favoritesListAll);
			favoritesList.add(theFavoritesList);
		}
				                
		return favoritesList;
		
	}
	
	@Override
	public List<Photos> getAllByUserId(int userId) {
		List<Photos> favoritesList = new ArrayList();
		
		String sqlFavoritesLists = "select * "
								+ "from photos "
								+ "inner join favorites "
								+ "on photos.photo_id = favorites.photo_id "
					            + "inner join users "
					            +"ON photos.user_id = users.user_id "
								+ "where favorites.user_id = ? ";
								
								
		SqlRowSet favoritesListAll = jdbcTemplate.queryForRowSet(sqlFavoritesLists, userId);
		while(favoritesListAll.next()) {
			Photos theFavoritesList = mapRowToPhoto(favoritesListAll);
			favoritesList.add(theFavoritesList);
		}
				                
		return favoritesList;
	}
	
	@Override
	public List<Photos> getLikesByUserId(int userId) {
		List<Photos> likesList = new ArrayList();
		
		String sqlLikesLists = "select * "
								+ "from photos "
								+ "inner join likes "
								+ "on photos.photo_id = likes.photo_id "
					            + "inner join users "
					            +"ON photos.user_id = users.user_id "
								+ "where likes.user_id = ? ";
								
								
		SqlRowSet likesListAll = jdbcTemplate.queryForRowSet(sqlLikesLists, userId);
		while(likesListAll.next()) {
			Photos theLikesList = mapRowToPhoto(likesListAll);
			likesList.add(theLikesList);
		}
				                
		return likesList;
	}
	
	public Photos getPhotoById(long photoId) {
		Photos photoListsById = new Photos();
		String sqlPhotoById = "select * "
				              + "from photos "
				              + "inner join users "
				              +"ON photos.user_id = users.user_id "
				              + "where photo_id = ? " ;
		SqlRowSet PhotoById = jdbcTemplate.queryForRowSet(sqlPhotoById, photoId);
		while(PhotoById.next()) {
			photoListsById = mapRowToPhoto(PhotoById);
		}
		
		
		return photoListsById;
	}
	
	 private Photos mapRowToPhoto(SqlRowSet results) {
	    	Photos photo = new Photos();
	    	photo.setPhotoId(results.getLong("photo_id"));
	    	photo.setCaption(results.getString("caption"));
	    	photo.setDateAdded(results.getDate("date_added").toLocalDate());
	    	photo.setTimeAdded(results.getTime("time_added").toLocalTime());
	    	photo.setUserId(results.getInt("user_id"));
	    	photo.setUrl(results.getString("url"));
	    	photo.setLikes(results.getInt("likes"));
	    	photo.setUsername(results.getString("username"));
	    			
	    	return photo;
	    }
	 
	 private long getNextPhotoId() {
			SqlRowSet nextPhotoIdResult = jdbcTemplate.queryForRowSet("SELECT nextval('seq_photos_id')");
			
			if(nextPhotoIdResult.next()) {
				return nextPhotoIdResult.getLong(1);
			}else {
				throw new RuntimeException ("Something went wrong while getting an id for the new photo");
			}
		}

	@Override
	public void deleteLike(int photoId) {
		
		
	}

	@Override
	public void deleteFavorite(int photoId) {
		// TODO Auto-generated method stub
		
	}


}
