package com.techelevator.application.model;

import java.time.LocalDate;
import java.time.LocalTime;

public class Photos {
	private long photoId;
	private String caption;
	private String url;
	private LocalDate dateAdded;
	private LocalTime timeAdded;
	private int userId;
	private int likes;
	private boolean isFavorited;
	private boolean isLiked;
	private String username;
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public boolean isLiked() {
		return isLiked;
	}
	public void setLiked(boolean isLiked) {
		this.isLiked = isLiked;
	}
	public boolean isFavorited() {
		return isFavorited;
	}
	public void setFavorited(boolean isFavorited) {
		this.isFavorited = isFavorited;
	}
	public int getLikes() {
		return likes;
	}
	public void setLikes(int likes) {
		this.likes = likes;
	}
	public long getPhotoId() {
		return photoId;
	}
	public void setPhotoId(long photoId) {
		this.photoId = photoId;
	}
	public String getCaption() {
		return caption;
	}
	public void setCaption(String caption) {
		this.caption = caption;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public LocalDate getDateAdded() {
		return dateAdded;
	}
	public void setDateAdded(LocalDate dateAdded) {
		this.dateAdded = dateAdded;
	}
	public LocalTime getTimeAdded() {
		return timeAdded;
	}
	public void setTimeAdded(LocalTime timeAdded) {
		this.timeAdded = timeAdded;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	
	public Photos () {
		
	}
	public Photos(Long photoId,String caption,String url, LocalDate dateadded, LocalTime timeAdded,int userId) {
		
	}
	@Override
	public String toString() {
		return "Photos [photoId=" + photoId + ", caption=" + caption + ", url=" + url + ", dateAdded=" + dateAdded
				+ ", timeAdded=" + timeAdded + ", userId=" + userId + "]";
	}

}
