package com.techelevator.application.jdbcdao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Service;

import com.techelevator.application.dao.FavoritesDAO;
import com.techelevator.application.model.Favorites;
@Service
public class FavoritesJDBCDAO implements FavoritesDAO {

private JdbcTemplate jdbcTemplate;
	
	public FavoritesJDBCDAO (JdbcTemplate jdbcTemplate, PhotosJDBCDAO photos) {
		this.jdbcTemplate = jdbcTemplate;
		
	}
	
	@Override
	public void create(int photoId, int userId) {
		String createNewFavorite = "insert into favorites "
                + "(user_id, photo_id) "
                + "values(?,?) ";
		jdbcTemplate.update(createNewFavorite, userId, photoId);
		
	}
	

	@Override
	public List<Favorites> getAllByUserId(int userId) {
		List<Favorites> favoritesList = new ArrayList();
		
		String sqlFavoritesLists = "select * "
								+ "from favorites "
								+ "inner join photos "
								+ "on photos.photo_id = favorites.photo_id "
								+ "where favorites.user_id = ? ";
								
								
		SqlRowSet favoritesListAll = jdbcTemplate.queryForRowSet(sqlFavoritesLists, userId);
		while(favoritesListAll.next()) {
			Favorites theFavoritesList = mapRowToFavorites(favoritesListAll);
			favoritesList.add(theFavoritesList);
		}
				                
		return favoritesList;
	}
	
	public void delete(int userId, int photoId) {
		String deleteFavorite = "delete from favorites "
				                + "where user_id = ? and photo_id = ? ";
		jdbcTemplate.update(deleteFavorite, userId,photoId);
	}

	private Favorites mapRowToFavorites(SqlRowSet results) {
    	Favorites favorite = new Favorites();
    	favorite.setFavoritesId(results.getLong("favorites_id"));
    	favorite.setUserId(results.getInt("user_id"));
    	favorite.setPhotoId(results.getInt("photo_id"));
    	favorite.setUrl(results.getString("url"));
    	
    	return favorite;
    }
 
 private long getNextFavoriteId() {
		SqlRowSet nextFavoriteIdResult = jdbcTemplate.queryForRowSet("SELECT nextval('favorites_favorites_id_seq')");
		
		
		if(nextFavoriteIdResult.next()) {
			return nextFavoriteIdResult.getLong(1);
		}else {
			throw new RuntimeException ("Something went wrong while getting an id for the new favorite");
		}
	}
}
