package com.techelevator.application.model;

public class Likes {
	private long likeId;
	private Boolean isLiked;
	private int photoId;
	private int userId;
	public long getLikeId() {
		return likeId;
	}
	public void setLikeId(long likeId) {
		this.likeId = likeId;
	}
	public Boolean getIsLiked() {
		return isLiked;
	}
	public void setIsLiked(Boolean isLiked) {
		this.isLiked = isLiked;
	}
	public int getPhotoId() {
		return photoId;
	}
	public void setPhotoId(int photoId) {
		this.photoId = photoId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	public Likes() {
		
	}
	public Likes(long likeId,Boolean isLiked,int photoId,int userId) {
		
	}
	@Override
	public String toString() {
		return "Likes [likeId=" + likeId + ", isLiked=" + isLiked + ", photoId=" + photoId + ", userId=" + userId + "]";
	}

}
