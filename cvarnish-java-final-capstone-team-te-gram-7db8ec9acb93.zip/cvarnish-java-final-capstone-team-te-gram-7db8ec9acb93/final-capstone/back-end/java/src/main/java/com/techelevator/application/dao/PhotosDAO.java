package com.techelevator.application.dao;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import com.techelevator.application.model.Photos;

public interface PhotosDAO {
	//Add photo
	//Photos create(long photoId, String caption, String url, LocalDate dateAdded, LocalTime timeAdded, int userId);
	void create(Photos NewPhoto, int userId);
	
	//Get photos by userID
	List<Photos> getbyUserId(Long userid);
	
	//Get photos by date
	List<Photos> getbyDate();
	
	//Get all
	List<Photos> getAll();
	
	List<Photos> getAllByUserId(int userId);
	
	Photos getPhotoById(long photoId);
	
	
	List<Photos> getFavorites(int userId);
	
	List<Photos> getLikesByUserId(int userId);
	
   void deleteLike(int photoId);
   void deleteFavorite(int photoId);
}	
