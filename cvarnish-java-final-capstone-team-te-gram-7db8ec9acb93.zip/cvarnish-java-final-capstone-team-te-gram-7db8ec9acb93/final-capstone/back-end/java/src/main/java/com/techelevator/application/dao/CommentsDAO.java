package com.techelevator.application.dao;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import com.techelevator.application.model.Comments;

public interface CommentsDAO {
	//Create
	void create(Comments comment);
	
	//Get comment by photo ID
	List<Comments>getCommentsByPhotoID(int photoId);
	
	//Edit/update comment(by photoID)??
	boolean edit(long commentId);
	
	//Delete a comment
	void delete(int userId, int photoId);
	
	List<Comments> getAllCommentsByPhotoID(int photoId);
}
