package com.techelevator.application.model;

import java.time.LocalDate;
import java.time.LocalTime;

public class Comments {
	private long commentId;
	private String comment;
	private LocalDate dateAdded;
	private LocalTime timeAdded;
	private int photoId;
	private String username;
	private int userId;
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public long getCommentId() {
		return commentId;
	}
	public void setCommentId(long commentId) {
		this.commentId = commentId;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
	  this.comment = comment;
	}
	public LocalDate getDateAdded() {
		return dateAdded;
	}
	public void setDateAdded(LocalDate dateAdded) {
		this.dateAdded = dateAdded;
	}
	public LocalTime getTimeAdded() {
		return timeAdded;
	}
	public void setTimeAdded(LocalTime timeAdded) {
		this.timeAdded = timeAdded;
	}
	public int getPhotoId() {
		return photoId;
	}
	public void setPhotoId(int photoId) {
		this.photoId = photoId;
	}
	
	public Comments () {
		
	}
	public Comments (long commentId,String Comment,LocalDate dateAdded, LocalTime timeAdded) {
		
	}
	@Override
	public String toString() {
		return "comments [commentId=" + commentId + ", Comment=" + comment + ", dateAdded=" + dateAdded + ", timeAdded="
				+ timeAdded + "]";
	}

}
