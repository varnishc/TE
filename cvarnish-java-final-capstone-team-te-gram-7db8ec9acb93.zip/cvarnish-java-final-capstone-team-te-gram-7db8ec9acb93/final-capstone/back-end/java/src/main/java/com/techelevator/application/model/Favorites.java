package com.techelevator.application.model;

public class Favorites {
 private Long favoritesId;
 private int userId;
 private int photoId;
 private String url;


 public String getUrl() {
	return url;
}
public void setUrl(String url) {
	this.url = url;
}
public Favorites() {
	 
 }
   public Favorites(Long favoritesId, int userId, int photoId) {
	   
 }
public Long getFavoritesId() {
	return favoritesId;
}
public void setFavoritesId(Long favoritesId) {
	this.favoritesId = favoritesId;
}
public int getUserId() {
	return userId;
}
public void setUserId(int userId) {
	this.userId = userId;
}
public int getPhotoId() {
	return photoId;
}
public void setPhotoId(int photoId) {
	this.photoId = photoId;
}
@Override
public String toString() {
	return "Favorites [favoritesId=" + favoritesId + ", userId=" + userId + ", photoId=" + photoId + "]";
}
   
}