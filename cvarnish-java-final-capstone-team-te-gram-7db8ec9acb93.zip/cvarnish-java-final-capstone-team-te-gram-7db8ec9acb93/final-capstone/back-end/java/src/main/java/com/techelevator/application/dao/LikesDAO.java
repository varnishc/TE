package com.techelevator.application.dao;

import java.util.List;

import com.techelevator.application.model.Likes;

public interface LikesDAO {
	// Create
	//void create(boolean isLiked, int photo_id, int user_id);
	void create(int photoId, int userId);
	
	// Get likes by photo ID
	List<Likes> getByPhotoId(int photoId);
	
	void delete(int photoId, int userId);
}
