package com.techelevator.application.jdbcdao;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Service;

import com.techelevator.application.dao.CommentsDAO;
import com.techelevator.application.model.Comments;
@Service
public class CommentsJDBCDAO implements CommentsDAO {
	
	private JdbcTemplate jdbcTemplate;
	
	public CommentsJDBCDAO (JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public void create(Comments newComment) {
		String insertComment = "Insert into comments "
							 + "(comment_id, comment, date_added, time_added,photo_id, user_id) "
							 + "Values(?,?,?,?,?,?)";
		
		newComment.setCommentId(getNextCommentId());
		LocalTime currentTime = LocalTime.now();
		LocalDate currentDate = LocalDate.now();
		newComment.setTimeAdded(currentTime);
		newComment.setDateAdded(currentDate);
	
		jdbcTemplate.update(insertComment, newComment.getCommentId(), newComment.getComment(), newComment.getDateAdded(), newComment.getTimeAdded(), newComment.getPhotoId(), newComment.getUserId());
		
	}

	@Override
	public List<Comments> getCommentsByPhotoID(int photoId) {
		List<Comments>commentsList = new ArrayList();
		
		String sqlComments = "SELECT * "
						   + "FROM comments "
						   + "inner join users "
						   + "ON comments.user_id = users.user_id "
						   + "WHERE comments.photo_id = ? "
						   + " order by date_added desc, time_added desc "
						   + " limit 1";
		
		SqlRowSet commentQuery = jdbcTemplate.queryForRowSet(sqlComments,photoId);
		while(commentQuery.next()) {
			Comments theComment = mapRowToComment(commentQuery);
			commentsList.add(theComment);
		}
		
		return commentsList;
	}
	
	@Override
	public List<Comments> getAllCommentsByPhotoID(int photoId) {
		List<Comments>commentsList = new ArrayList();
		
		String sqlComments = "SELECT * "
						   + "FROM comments "
						   + "inner join users "
						   + "ON comments.user_id = users.user_id "
						   + "WHERE comments.photo_id = ? "
						   + " order by date_added desc, time_added desc ";
		
		SqlRowSet commentQuery = jdbcTemplate.queryForRowSet(sqlComments,photoId);
		while(commentQuery.next()) {
			Comments theComment = mapRowToComment(commentQuery);
			commentsList.add(theComment);
		}
		
		return commentsList;
	}

	@Override
	public boolean edit(long commentId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void delete(int userId, int photoId) {
		String deleteAComment = "delete from comments "
				                + "where user_id = ? and photo_id = ? ";
		jdbcTemplate.update(deleteAComment, userId, photoId);
		
	}

    private Comments mapRowToComment(SqlRowSet results) {
    	Comments comment = new Comments();
    	comment.setComment(results.getString("comment"));
    	comment.setDateAdded(results.getDate("date_added").toLocalDate());
    	comment.setTimeAdded(results.getTime("time_added").toLocalTime());
    	comment.setPhotoId(results.getInt("photo_id"));
    	comment.setUsername(results.getString("username"));
    	comment.setUserId(results.getInt("user_id"));
    	return comment;
    }
    
    private long getNextCommentId() {
		SqlRowSet nextCommentIdResult = jdbcTemplate.queryForRowSet("SELECT nextval('seq_comments_id')");
		
		if(nextCommentIdResult.next()) {
			return nextCommentIdResult.getLong(1);
		}else {
			throw new RuntimeException ("Something went wrong while getting an id for the new transfer");
		}
	}
}
