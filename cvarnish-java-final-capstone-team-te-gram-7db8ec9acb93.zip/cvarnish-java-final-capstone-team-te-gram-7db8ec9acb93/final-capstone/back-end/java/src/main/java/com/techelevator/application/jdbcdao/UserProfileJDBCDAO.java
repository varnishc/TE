package com.techelevator.application.jdbcdao;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Service;

import com.techelevator.application.dao.UserProfileDAO;
import com.techelevator.application.model.UserProfile;
@Service
public class UserProfileJDBCDAO implements UserProfileDAO {
	private JdbcTemplate jdbcTemplate;
	
	public UserProfileJDBCDAO (JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public UserProfile create(long profileId, int userId, String email) {
		String createNewProfile = "insert into user_profile "
				                  + "(profile_id, user_id, email)"
				                  + "values(?,?,?) ";
		 jdbcTemplate.update(createNewProfile, profileId, userId, email);
		
		UserProfile newProfile =  findByUserId(userId );
		
		return newProfile;
	}

	@Override
	public UserProfile findByEmail(String email) {
		
		UserProfile theProfileByEmail = new UserProfile();
		String QueryForprofile = "select * "
				                 + "from user_profile"
				                 + "where email = ?";
		SqlRowSet theProfile = jdbcTemplate.queryForRowSet(QueryForprofile, email);
		while(theProfile.next()) {
			theProfileByEmail = mapRowToUserProfile(theProfile);
		}
		
		return theProfileByEmail;
	}

	@Override
	public UserProfile findByUserId(int userId) {
		UserProfile theProfileById = new UserProfile();
		String QueryForprofile = "select * "
				                 + "from user_profile"
				                 + "where user_id = ?";
		SqlRowSet theProfile = jdbcTemplate.queryForRowSet(QueryForprofile, userId);
		while(theProfile.next()) {
			theProfileById = mapRowToUserProfile(theProfile);
		}
		
		return theProfileById;
	}
	
	private long getNextUserProfileId() {
		SqlRowSet nextUserProfileIdResult = jdbcTemplate.queryForRowSet("SELECT nextval('seq_user_profile_id')");
		
		if(nextUserProfileIdResult.next()) {
			return nextUserProfileIdResult.getLong(1);
		}else {
			throw new RuntimeException ("Something went wrong while getting an id for the new transfer");
		}
	}
	private UserProfile mapRowToUserProfile(SqlRowSet results) {
    	UserProfile theUserProfile = new UserProfile();
    	theUserProfile.setProfileId(results.getLong("profile_id"));
    	theUserProfile.setEmail(results.getString("email"));
    	theUserProfile.setUserId(results.getInt("user_id"));
    	
    	return theUserProfile;
    }

}
