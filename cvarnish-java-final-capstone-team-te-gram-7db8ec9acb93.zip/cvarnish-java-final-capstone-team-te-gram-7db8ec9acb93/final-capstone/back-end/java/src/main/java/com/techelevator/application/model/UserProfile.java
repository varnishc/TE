package com.techelevator.application.model;

public class UserProfile {
	private long profileId;
	private int userId;
	private String email;
	public Long getProfileId() {
		return profileId;
	}
	public void setProfileId(Long profileId) {
		this.profileId = profileId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public UserProfile () {
		
	}
	public UserProfile (long profileId, int userId,String email) {
		
	}
	@Override
	public String toString() {
		return "UserProfile [profileId=" + profileId + ", userId=" + userId + ", email=" + email + "]";
	}

}
