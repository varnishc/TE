package com.techelevator.application.dao;

import com.techelevator.application.model.UserProfile;

public interface UserProfileDAO {
	//Create
	UserProfile create(long profileId, int userId, String email);
	
	//Read
	UserProfile findByEmail(String email);
	UserProfile findByUserId(int userId);
	
	//Delete??
}
