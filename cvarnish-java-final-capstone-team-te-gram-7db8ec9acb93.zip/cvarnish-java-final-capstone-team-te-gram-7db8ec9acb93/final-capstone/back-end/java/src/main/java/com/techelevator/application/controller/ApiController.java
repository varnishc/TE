/********************************************************************************************************************** 
* This will should contain Application API Controllers and related objects
**********************************************************************************************************************/

package com.techelevator.application.controller;

import java.security.Principal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.techelevator.application.dao.CommentsDAO;
import com.techelevator.application.dao.FavoritesDAO;
import com.techelevator.application.dao.LikesDAO;
import com.techelevator.application.dao.PhotosDAO;
import com.techelevator.application.model.Comments;
import com.techelevator.application.model.Favorites;
import com.techelevator.application.model.Likes;
import com.techelevator.application.model.Photos;
import com.techelevator.security.dao.UserDAO;
import com.techelevator.security.model.User;

@RestController
@CrossOrigin
public class ApiController {
	private PhotosDAO photosDAO;
	private CommentsDAO commentsDAO;
	private UserDAO userDAO;
	private LikesDAO likesDAO;
	private FavoritesDAO favoritesDAO;
	
	
public ApiController(PhotosDAO photosDAO, CommentsDAO commentsDAO, UserDAO userDAO, LikesDAO likesDAO, FavoritesDAO favoritesDAO) {
	this.photosDAO = photosDAO;
	this.commentsDAO = commentsDAO;
	this.userDAO = userDAO;
	this.likesDAO = likesDAO;
	this.favoritesDAO = favoritesDAO;
}

/**********************************************************************************************************************
* Put your Application API Controllers here
**********************************************************************************************************************/
@RequestMapping(path = "/photos", method = RequestMethod.POST)
@ResponseStatus(value = HttpStatus.CREATED)
public void createPhoto(@RequestBody Photos newPhoto, Principal currentUser) {
	int userId = userDAO.findIdByUsername(currentUser.getName());
	logRequest("User id making request: " +userId);
	photosDAO.create(newPhoto, userId);
}

@RequestMapping(path = "/photos", method = RequestMethod.GET)
public List<Photos> getAllPhotos() {
	logRequest("Getting all Photos...");
	return photosDAO.getAll();
}

@RequestMapping(path = "/photos/{userid}", method = RequestMethod.GET)
public List<Photos> getPhotoById( @PathVariable Long userid) {
	logRequest("Getting a photo using user ID...");
	return photosDAO.getbyUserId(userid);
}

@RequestMapping(path = "/photos/comments", method = RequestMethod.POST)
@ResponseStatus(value = HttpStatus.CREATED)
public void createComments(Principal currentUser, @RequestBody Comments newComment) {
	int userId = userDAO.findIdByUsername(currentUser.getName());
	newComment.setUserId(userId);
	logRequest("Adding a comment...");
	commentsDAO.create(newComment);
}

@RequestMapping(path = "/photos/comments/{photoId}", method = RequestMethod.GET)
public List<Comments>getCommentsByPhotoID(@PathVariable int photoId){
	logRequest("Getting a comment using photo ID...");
	return commentsDAO.getCommentsByPhotoID(photoId);
}

@RequestMapping(path = "/photos/comments/view/{photoId}", method = RequestMethod.GET)
public List<Comments>getAllCommentsByPhotoID(@PathVariable int photoId){
	logRequest("Getting a comment using photo ID...");
	return commentsDAO.getAllCommentsByPhotoID(photoId);
}

@RequestMapping(path = "/photos/comments/{photoId}", method = RequestMethod.DELETE)
@ResponseStatus(value = HttpStatus.NO_CONTENT)
public void deleteComment(Principal currentUser, @PathVariable int photoId) {
	int userId = userDAO.findIdByUsername(currentUser.getName());
	logRequest("Deleting a comment...");
	commentsDAO.delete(userId, photoId);
}

@RequestMapping(path = "/photos/likes/{photoId}", method = RequestMethod.GET)
public List<Likes>getLikesByPhotoId(@PathVariable int photoId){
	logRequest("Getting a like using photo ID...");
	return likesDAO.getByPhotoId(photoId);
	
}

@RequestMapping(path = "/photos/favorites/{photoId}", method = RequestMethod.POST)
@ResponseStatus(value = HttpStatus.CREATED)
public void createFavorite(Principal currentUser, @PathVariable int photoId){
	int userId = userDAO.findIdByUsername(currentUser.getName());
	logRequest("Creating a favorite...");
	 favoritesDAO.create(photoId, userId);
	
}
@RequestMapping(path = "/photos/likes/{photoId}", method = RequestMethod.POST)
@ResponseStatus(value = HttpStatus.CREATED)
public void createLikes(Principal currentUser, @PathVariable int photoId){
	int userId = userDAO.findIdByUsername(currentUser.getName());
	logRequest("Creating a like...");
	 likesDAO.create(photoId, userId);
	
}

@ResponseStatus(HttpStatus.NO_CONTENT)
@RequestMapping(path = "/photos/likes/{photoId}", method = RequestMethod.DELETE)
 public void deleteLike(Principal currentUser, @PathVariable int photoId) {
	
	int userId = userDAO.findIdByUsername(currentUser.getName());
	logRequest("Deleting a like...");
	 likesDAO.delete(photoId, userId);
	
	  
}

@ResponseStatus(HttpStatus.NO_CONTENT)
@RequestMapping(path = "/photos/favorites/{photoId}", method = RequestMethod.DELETE)
 public void deleteFavorite(Principal currentUser, @PathVariable int photoId) {
	
	int userId = userDAO.findIdByUsername(currentUser.getName());
	logRequest("Deleting a favorite...");
	 favoritesDAO.delete(userId, photoId);
	
	  
}

@RequestMapping(path = "photos/favorites", method = RequestMethod.GET)
public List<Photos>getUserFavorites(Principal currentUser){
	int userId = userDAO.findIdByUsername(currentUser.getName());
	logRequest("Getting a users Favorite Photos...");
	return photosDAO.getAllByUserId(userId);
}
	  
	 

@RequestMapping(path = "/photos/favorites/{userId}", method = RequestMethod.GET)
public List<Long>getAllByUserId(Principal currentUser, @PathVariable int userId){
	userId = userDAO.findIdByUsername(currentUser.getName());
	logRequest("Getting all favorites using user ID...");
	List<Photos> photoList = photosDAO.getAllByUserId(userId);
	List<Long> photoIds = new ArrayList<Long>();
	for (int i=0; i < photoList.size(); i++) {
		photoIds.add(photoList.get(i).getPhotoId());
	}
	return photoIds;
}
	
	@RequestMapping(path = "/photos/likes/like{userId}", method = RequestMethod.GET)
	public List<Long>getLikesByUserId(Principal currentUser, @PathVariable int userId){
		userId = userDAO.findIdByUsername(currentUser.getName());
		logRequest("Getting all likes using user ID...");
		List<Photos> photoList = photosDAO.getLikesByUserId(userId);
		List<Long> photoIds = new ArrayList<Long>();
		for (int i=0; i < photoList.size(); i++) {
			photoIds.add(photoList.get(i).getPhotoId());
		}
		return photoIds;
}

//@RequestMapping(path = "/photos/{userid}", method = RequestMethod.GET)
//public List<Photos> getPhotoById( @PathVariable Long userid) {
//	logRequest("Getting a photo using user ID...");
//	return photosDAO.getbyUserId(userid);










/********************************************************************************************************************* 
* Use this method if you'd like to log calls to your controllers - these message can aid in your troubleshooting
* 
* To use it: logRequest("a message you want to appear after the timestamp in the server log")
* 
* There are examples in the AuthenicationController.java program in the com.techelevator.security.controller package
**********************************************************************************************************************/	
    static void logRequest(String message) {
    	Timestamp timestamp = new Timestamp(System.currentTimeMillis());
    	 
    	System.out.println(timestamp + " - " + message);
    }
}

