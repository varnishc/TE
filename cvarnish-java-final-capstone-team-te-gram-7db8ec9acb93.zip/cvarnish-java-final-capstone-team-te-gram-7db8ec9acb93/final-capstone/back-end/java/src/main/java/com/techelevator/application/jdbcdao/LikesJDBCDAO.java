package com.techelevator.application.jdbcdao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Service;

import com.techelevator.application.dao.LikesDAO;
import com.techelevator.application.dao.PhotosDAO;
import com.techelevator.application.model.Comments;
import com.techelevator.application.model.Likes;
@Service
public class LikesJDBCDAO implements LikesDAO {
	private JdbcTemplate jdbcTemplate;
	private PhotosDAO photosDAO;
	
	public LikesJDBCDAO (JdbcTemplate jdbcTemplate, PhotosDAO photosDAO) {
		this.jdbcTemplate = jdbcTemplate;
		this.photosDAO = photosDAO;
	}
	

	@Override
	public void create(int photoId, int userId) {
		
		String createNewLike = "insert into likes "
                + "(user_id, photo_id) "
                + "values(?,?) ";
		jdbcTemplate.update(createNewLike, userId, photoId);
		
		String updateLikes = "UPDATE photos "
							+"SET likes = likes + 1 "
							+"WHERE photo_id = ?";
		jdbcTemplate.update(updateLikes, photoId);
	}

	@Override
	public void delete(int photoId, int userId) {
		
		String deleteLike = "delete from likes "
							+ "where user_id = ? and photo_id = ?";
		
		jdbcTemplate.update(deleteLike, userId, photoId);
	
		
		String updateLikes = "UPDATE photos "
				+"SET likes = likes - 1 "
				+"WHERE photo_id = ? ";
		jdbcTemplate.update(updateLikes, photoId);
	}
	
	@Override
	public List<Likes> getByPhotoId(int photoId) {
		List<Likes> getAllLikesByPhotoId = new ArrayList();
		String sqlLikes = "select * "
				          + "from Likes "
				          + "inner join "
				          + "photos "
				          + "on photos.photo_id = likes.photo_id "
				          + "where photos.photo_id = ? ";
		SqlRowSet likeQuery = jdbcTemplate.queryForRowSet(sqlLikes,photoId);
		while(likeQuery.next()) {
			Likes theLike = mapRowToLikes(likeQuery);
			getAllLikesByPhotoId.add(theLike);
		}
		
		
		
		
		return getAllLikesByPhotoId;
	}
	
	private Likes mapRowToLikes(SqlRowSet results) {
    	Likes like = new Likes();
    	like.setLikeId(results.getLong("like_id"));
    	like.setPhotoId(results.getInt("photo_id"));
    	like.setUserId(results.getInt("user_id"));
    	
    	return like;
    }
	
	private long getNextLikeId() {
		SqlRowSet nextLikeIdResult = jdbcTemplate.queryForRowSet("SELECT nextval('seq_likes_id')");
		
		if(nextLikeIdResult.next()) {
			return nextLikeIdResult.getLong(1);
		}else {
			throw new RuntimeException ("Something went wrong while getting an id for the new transfer");
		}
	}

}
