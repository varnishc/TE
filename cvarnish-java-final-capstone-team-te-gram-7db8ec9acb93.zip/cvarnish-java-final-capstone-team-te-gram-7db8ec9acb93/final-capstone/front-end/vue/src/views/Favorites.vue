<template>
    <div class="main">
        <photo-display :photos="photos"/>
    </div>
</template>

<script>
import photoDisplay from '../components/photoDisplay.vue'
import applicationService from '../services/ApplicationServices'

export default {
  components: { photoDisplay },
    name: 'favorites',

    data(){
        return{
            photos: [],
            favoritedPhotos: []
        }
    },



    created(){
       applicationService.getFavoritePhotos().then(response => {
           this.photos = response.data;

    applicationService.getUserFavorites(this.$store.state.user.id).then(response => {
        this.favoritedPhotos = response.data

        this.photos.forEach(aPhoto => {
            if (this.favoritedPhotos.includes(aPhoto.photoId)){
                aPhoto.favorited = true;
            }
            else {
                aPhoto.favorited = false;
            }
        })
        }) 
      applicationService.getUserLikes(this.$store.state.user.id).then(response => {
        this.likedPhotos = response.data

          this.photos.forEach(aPhoto => {
            if (this.likedPhotos.includes(aPhoto.photoId)){
                aPhoto.liked = true;
            }
            else {
                aPhoto.liked = false;
            }
        })
      })
       })
    }
}
</script>

<style scoped>

.main{
    min-height: 100vh;
}

</style>
