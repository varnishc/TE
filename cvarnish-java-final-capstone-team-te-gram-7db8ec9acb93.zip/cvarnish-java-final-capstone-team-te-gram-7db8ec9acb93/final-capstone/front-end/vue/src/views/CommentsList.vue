<template>
<div class="wrapper">
    <div class="comment-display" v-for="comment in comments" v-bind:key="comment.id">
       <router-link class="comment-link" v-bind:to="{ name: 'user', params: { id: comment.userId } }"> {{comment.username}} </router-link>  
        <span class="comment-text"> {{comment.comment}}</span> 
        
        </div>


        </div>
</template>

<script>

import applicationService from '@/services/ApplicationServices'

export default {
  name: 'CommentsList',

  data(){
      return{
      comments: []
      }
  },
  props: ['photo'],

  created(){
      applicationService.getAllComments(this.$route.params.photoId).then(response => {
          console.log(response.data)
          this.comments = response.data
      })
  }
  
}
</script>

<style scoped>

.wrapper{
    min-height: 100vh;
    padding-bottom: 7em;
}
.comment-display {

     background-color: #FFFFFF;
        width: 603px;
        height: 75px;
        margin: auto;
        margin-bottom: 20px;
        margin-top: 40px;
        border-radius: 1.5em;
        box-shadow: 0px 11px 35px 2px rgba(0, 0, 0, 0.14);
        display: flex;
        justify-content: flex-start;
    
}
a {
    font-weight: bold;
    text-decoration: none;
     padding-top: 20px;
     padding-right: 10px;
     margin-left: 15px;
     
   
}

.comment-text {
   
   padding-top: 20px;
  
}


</style>
