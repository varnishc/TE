

<template>

  <div class="home">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Grand+Hotel&display=swap" rel="stylesheet">

    <!-- <h1 class="logo">TEgram</h1> -->
 
    <photo-display :photos="photos"/>

    <photo-upload-feed @image-upload="imageUpload"/>
    <form v-on:submit.prevent="photoToServer">
      <textarea class="caption" v-model="photo.caption" rows="6" cols="50"> </textarea>
      <div>
      <button class="submit-button" type='submit'> Submit photo and caption </button>
      </div>
     </form>
   </div>
   
</template>

<script>
import photoDisplay from '@/components/photoDisplay'
import photoUploadFeed from "@/components/photoUploadFeed"
import applicationService from "@/services/ApplicationServices"

export default {
  components: { 
    photoUploadFeed,
    photoDisplay
    
     },
  name: "home",
  data() {
    return {
      photo: {
      caption: "",
      url: "",
      time_added: "",
      user_id: ""
      },
      photos: [],
      favoritedPhotos: [],
      likedPhotos:[]

  }

  },
  created() {
    applicationService.getAllPhotos().then(response =>{
            this.photos = response.data
    applicationService.getUserFavorites(this.$store.state.user.id).then(response => {
        this.favoritedPhotos = response.data

        this.photos.forEach(aPhoto => {
            if (this.favoritedPhotos.includes(aPhoto.photoId)){
                aPhoto.favorited = true;
            }
            else {
                aPhoto.favorited = false;
            }
        })
        }) 
      applicationService.getUserLikes(this.$store.state.user.id).then(response => {
        this.likedPhotos = response.data

          this.photos.forEach(aPhoto => {
            if (this.likedPhotos.includes(aPhoto.photoId)){
                aPhoto.liked = true;
            }
            else {
                aPhoto.liked = false;
            }
        })
      })

        })

  },
 methods: {
   imageUpload(value){
     this.photo.url=value
   },
   photoToServer(){
     applicationService.createPhoto(this.photo).then(response => {
       if(response.status === 201){
         alert("Your photo has been submitted!")
         this.$router.push({name: 'user', params:{id:this.$store.state.user.id}})
       }
     })
   }
 }
}
</script>
<style scoped>

div.home {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #b4d2f0;
  max-width: 800px;
  margin: 60px auto 0 auto;
  min-height: 100vh;
}
.caption{
  margin-top: 20px;
}
.logo {
  font-family: 'Grand Hotel', cursive;
  font-size: 40px;
}

</style>

