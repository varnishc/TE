<template>
 <div class="home"> 

  <photo-display :photos="photos"/>


   
    
  
 </div>
    
</template>

<script>
import photoDisplay from '@/components/photoDisplay.vue'
import applicationService from '@/services/ApplicationServices'

export default {
    name: 'user',

    components:{
        photoDisplay

    },
    
    data(){
        return{
            photos: [],
        }

    },
    created() {
        applicationService.getUserPhotos(this.$route.params.id).then(response =>{
            this.photos = response.data;
            

            applicationService.getUserFavorites(this.$store.state.user.id).then(response => {
        this.favoritedPhotos = response.data

        this.photos.forEach(aPhoto => {
            if (this.favoritedPhotos.includes(aPhoto.photoId)){
                aPhoto.favorited = true;
            }
            else {
                aPhoto.favorited = false;
            }
        })
        }) 

      applicationService.getUserLikes(this.$store.state.user.id).then(response => {
        this.likedPhotos = response.data

          this.photos.forEach(aPhoto => {
            if (this.likedPhotos.includes(aPhoto.photoId)){
                aPhoto.liked = true;
            }
            else {
                aPhoto.liked = false;
            }
        })
      })

        })
        
    },
    watch: {
    '$route.params.id': function() {
      window.location.reload();
    }
  },

   
}
</script>

<style scoped>

div.home {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #b4d2f0;
  max-width: 800px;
  margin: 60px auto 0 auto;
  min-height: 100vh;
}
</style>
