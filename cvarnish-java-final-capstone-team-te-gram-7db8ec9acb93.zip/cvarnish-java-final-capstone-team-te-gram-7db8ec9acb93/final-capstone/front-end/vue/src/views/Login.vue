<template>

<div class="wrapper">

  <div class="main">
  <div id="login" class="text-center">
    <form class="form-signin form1" @submit.prevent="login">
      <h1 class="h3 mb-3 font-weight-normal sign">Please Sign In</h1>
      <div
        class="alert alert-danger"
        role="alert"
        v-if="invalidCredentials"
      >Invalid username and password!</div>
      <div
        class="alert alert-success"
        role="alert"
        v-if="this.$route.query.registration"
      >Thank you for registering, please sign in.</div>
      <div> 
      <label for="username" class="sr-only"></label>
      <input
        type="text"
        id="username"
        class="form-control un "
        align="center"
        placeholder="Username"
        v-model="user.username"
        required
        autofocus
      />
      </div>
      <div>
      <label for="password" class="sr-only"></label>
      <input
        type="password"
        id="password"
        class="form-control pass"
        placeholder="Password"
        v-model="user.password"
        required
      />
      </div>
      <div class="link">
      <router-link :to="{ name: 'register' }">Need an account?</router-link>
      </div>
      <p>
        
      </p>
      <button type="submit" class="submit"> Sign in</button>
    </form>
    </div>
  
  </div>
  </div>

</template>

<script>
import authService from "../services/AuthService";

export default {
  name: "login",
  components: {},
  data() {
    return {
      user: {
        username: "",
        password: ""
      },
      invalidCredentials: false
    };
  },
  methods: {
    login() {
      authService
        .login(this.user)
        .then(response => {
          if (response.status == 200) {
            this.$store.commit("SET_AUTH_TOKEN", response.data.token);
            this.$store.commit("SET_USER", response.data.user);
            this.$router.push("/");
          }
        })
        .catch(error => {
          const response = error.response;

          if (response.status === 401) {
            this.invalidCredentials = true;
          }
        });
    }
  }
};
</script>

<style scoped>
.wrapper{
  min-height: 84vh;
}

    .un {
    width: 76%;
    color: rgb(38, 50, 56);
    font-weight: 700;
    font-size: 14px;
    letter-spacing: 1px;
    background: rgba(136, 126, 126, 0.04);
    padding: 10px 20px;
    border: none;
    border-radius: 20px;
    outline: none;
    box-sizing: border-box;
    border: 2px solid rgba(0, 0, 0, 0.02);
    margin-bottom: 50px;
    margin-left: 46px;
    text-align: center;
    margin-bottom: 27px;
    font-family: 'Ubuntu', sans-serif;
    }
  
    .main {
        
        background-color: #FFFFFF;
        width: 400px;
        height: 400px;
        margin: 7em auto;
        border-radius: 1.5em;
        box-shadow: 0px 11px 35px 2px rgba(0, 0, 0, 0.14);
    }
    
    h1.sign {
        padding-top: 10px;
        color: #2c1972;
        font-family: 'Ubuntu', sans-serif;
        font-weight: bold;
        font-size: 23px;
        display: grid;
        align-content: center;
        justify-content: center;
    }
    
    form.form1 {
        padding-top: 40px;
    }
    
    .pass {
            width: 76%;
    color: rgb(38, 50, 56);
    font-weight: 700;
    font-size: 14px;
    letter-spacing: 1px;
    background: rgba(136, 126, 126, 0.04);
    padding: 10px 20px;
    border: none;
    border-radius: 20px;
    outline: none;
    box-sizing: border-box;
    border: 2px solid rgba(0, 0, 0, 0.02);
    margin-bottom: 50px;
    margin-left: 46px;
    text-align: center;
    margin-bottom: 27px;
    font-family: 'Ubuntu', sans-serif;
    }
    
    .submit {
      cursor: pointer;
        border-radius: 5em;
        color: #fff;
        background: linear-gradient(to right, #200a55, #644cce);
        border: 0;
        margin-left: 140px;
        padding-left: 40px;
        padding-right: 40px;
        padding-bottom: 10px;
        padding-top: 10px;
        font-family: 'Ubuntu', sans-serif;
        font-size: 13px;
        box-shadow: 0 0 20px 1px rgba(0, 0, 0, 0.04);
    }

      .link{
      margin-left: 140px;
    }
    
</style>

