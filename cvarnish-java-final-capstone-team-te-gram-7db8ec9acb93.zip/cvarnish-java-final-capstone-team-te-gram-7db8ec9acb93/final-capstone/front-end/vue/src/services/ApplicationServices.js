/**************************************************************************************
* This file is provided for you to use for any Application services you may create
*
*  If you would prefer a file with a different name for your services, 
*     simply create one 
***************************************************************************************/
import axios from 'axios';

export default {
    createPhoto(photo){
        return axios.post('/photos', photo)
    },
    getAllPhotos(){
        return axios.get('/photos')
    },
    getUserPhotos(userId){
        return axios.get(`/photos/${userId}`)
    },
    favoriteAPhoto(photoId){
        return axios.post(`/photos/favorites/${photoId}`)
    },
    unfavoriteAPhoto(photoId){
        return axios.delete(`/photos/favorites/${photoId}`)
    },
    likeAPhoto(photoId){
        return axios.post(`/photos/likes/${photoId}`)
    },
    unlikeAPhoto(photoId){
        return axios.delete(`/photos/likes/${photoId}`)
    },
    getUserFavorites(userId){
        return axios.get(`/photos/favorites/${userId}`)
     },
     getUserLikes(userId){
        return axios.get(`photos/likes/like${userId}`)
     },
     getFavoritePhotos(){
         return axios.get('/photos/favorites')
     },
     createComment(comment){
         return axios.post('/photos/comments', comment)
     },
     getOneComment(photoId){
         return axios.get(`/photos/comments/${photoId}`)
     },
     getAllComments(photoId){
         return axios.get(`/photos/comments/view/${photoId}`)
     }


    
}