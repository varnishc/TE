<template>
   <div> <router-link v-bind:to="{ name: 'user', params: { id: firstComment.userId } }"> {{firstComment.username}} </router-link>  
        <span> {{firstComment.comment}}</span> 
   </div>
</template>

<script>

import applicationService from '@/services/ApplicationServices'
export  default{

    created() { 
            applicationService.getOneComment(this.photo.photoId).then(response => {
                this.firstComment = response.data[0] 
            })   
    },
    props: ['photo'],

    data(){
        return{
            firstComment: ''
        }
    }
}
</script>

<style scoped>
a {
    font-weight: bold;
    text-decoration: none;
    
}

span {
    margin-left: 5px;
    
}

</style>