<template>

        <form v-on:submit.prevent="addComment(photo)">
      <textarea class="comments-box" v-model="comments.comment" placeholder="Place your comment here"> </textarea>
      <div class="comment-submit">
          <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css" integrity="sha384-gfdkjb5BdAXd+lj+gudLWI+BXq4IuLW5IT+brZEZsLFm++aCMlF1V92rMkPaX4PP" crossorigin="anonymous">

      <!-- <button class="submit-button" type='submit'> Submit comment </button> -->
        <button class="submit-button"> <i class="fas fa-comment-dots"></i> Submit Comment </button>
      <router-link v-bind:to="{ name: 'CommentsList', params: {photoId:photo.photoId}}"><i class="fas fa-comments"></i> View All Comments </router-link>
      </div>
     </form>

      
 
      
   
    


</template>

<script>

import applicationService from '@/services/ApplicationServices'

export default {
    props: ['photo'],

    data() {
        return {
        comments : {
            comment: '',
            photoId: ''
        }
    }
        
    },
    methods: {
          addComment(photos){
            this.comments.photoId = photos.photoId
            if (this.comments.comment !== '') {
              applicationService.createComment(this.comments).then(response =>{
                if(response.status === 201){
                    this.comments.comment = ''
                    this.comments.photoId = ''
                alert("Your comment has been submitted!")
                window.location.reload()
                }
            })
            }
        },
            viewAllComments(photo){
                applicationService.getAllComments(photo.photoId).then(response =>{
                    if(response.status === 201){
                        this.$router.push({name: 'commentslist'})
                    }
                })

            }
    }
}
</script>

<style scoped>
.comments-box{
    border-bottom-right-radius: 1.5em;
    border-bottom-left-radius: 1.5em;
    border:none;
    outline: none;
    font-family: "Avenir", Helvetica, Arial, sans-serif;
    margin-top: 20px;
    margin-left: 20px;
    height: 60px;
    width: 550px;
}
.comment-submit {
    display:flex;
    justify-content: center;
}
.submit-button {
    margin-right:30px;
    background: none!important;
  border: none;
  padding: 0!important;
  /*optional*/
    font-family: "Avenir", Helvetica, Arial, sans-serif;
  /*input has OS specific font-family*/
  color: black;
  cursor: pointer;
  font-weight: bold;
  font-size: medium;
}
a {
    text-decoration: none;
    font-weight: bold;
    color: #551A8B;

}

</style>
