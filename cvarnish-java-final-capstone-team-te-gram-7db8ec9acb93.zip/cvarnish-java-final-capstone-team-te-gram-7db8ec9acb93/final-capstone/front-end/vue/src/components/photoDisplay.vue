<template>
<div class="wrapper">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css" integrity="sha384-gfdkjb5BdAXd+lj+gudLWI+BXq4IuLW5IT+brZEZsLFm++aCMlF1V92rMkPaX4PP" crossorigin="anonymous">
    <div v-for="photo in photos" v-bind:key="photo.id">
    
    <div class="img-well">
    <img v-bind:src="photo.url" />
    <div class="flex-container">
    

    <div class="like">
      
        
        
        <i v-if="!photo.liked" class= "far fa-heart fa-2x" v-on:click="liked(photo)"></i>


        <i v-else class="fas fa-heart fa-2x full-heart" v-on:click="liked(photo)"></i>

        <i v-if="!photo.favorited" class="far fa-bookmark fa-2x favorite" v-on:click="favorited(photo)"></i>
        <i v-else class="fas fa-bookmark fa-2x full-favorite" v-on:click="favorited(photo)"></i>
        
        

        </div>

        <span class="number-likes">{{photo.likes}} Likes</span>

        <div class="caption-div">
        <p class="username">  <router-link v-bind:to="{ name: 'user', params: { id: photo.userId } }"> {{photo.username}} </router-link> </p>
        <p class="caption"> {{photo.caption}} </p>
        </div>
        <div class="first-comment">
               <first-comment :photo="photo"/>
            </div>
          <div class="comments">
              <submit-comment :photo="photo"/>
        </div>
        </div>
    </div>
    </div>



</div>

</template>

<script>
import firstComment from '@/components/firstComment'
import applicationService from '@/services/ApplicationServices'
import submitComment from '@/components/submitComment'

export default {
    name: 'photodisplay',
    components: {
        submitComment,
        firstComment
    }, 
       data() {
        return {
           likedPhotos: [],
           favoritedPhotos: [],
           comments: {
               comment: '',
               photoId: ''
           }, 
        }
    },
    props: ['photos'],

    created(){
        
        
    },
    methods: {
        liked(photo){
            if (photo.liked === false){
                photo.liked = true;
                applicationService.likeAPhoto(photo.photoId);
                photo.likes ++;
            }
            else {
                photo.liked = false;
                applicationService.unlikeAPhoto(photo.photoId);
                if(photo.likes > 0) {
                    photo.likes --;
                }
            }
        },
        favorited(photo) {
            if(photo.favorited === false){
                photo.favorited = true;
                applicationService.favoriteAPhoto(photo.photoId);
            }
            else {
                photo.favorited = false;
                applicationService.unfavoriteAPhoto(photo.photoId);
            }
        },
        // getFirstComment(photo) {
        //     applicationService.getOneComment(photo.photoId).then(response => {
        //         return response.data.comment
                
                
        //     })
            
            
        // }

    }
}
   

</script>

<style scoped>
a {
    font-weight: bold;
    text-decoration: none;
}
.number-likes{
    margin-left: 10px;
    color: black;
}

.first-comment{
    color: black;
    font-family: "Avenir", Helvetica, Arial, sans-serif;
    padding-left: 10px;
}

.comments{
    display: flex;
    flex-direction: column;
    justify-items: center;
    color: black;
    font-family: "Avenir", Helvetica, Arial, sans-serif;
}

.flex-container{
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    
}
.username{
    display: flex;
    flex-direction: row;
    color: black;
    padding-left: 10px;
    font-family: "Avenir", Helvetica, Arial, sans-serif;
}

.caption{
    color: black;
    /* align-content: center; */
    justify-content: flex-start;
    padding-left: 10px;
    font-family: "Avenir", Helvetica, Arial, sans-serif;
}
.caption-div{
    display: flex;
    flex-direction: row;
}

.wrapper{
    padding-bottom: 7em;
}

img{
    width: 603px;
    height: 500px;
    object-fit: cover;
    align-content: center;
    border-top-left-radius: 1.5em;
    border-top-right-radius: 1.5em;
}

.img-well{
        background-color: #FFFFFF;
        width: 603px;
        height: 800px;
        margin: 7em auto;
        border-radius: 1.5em;
        box-shadow: 0px 11px 35px 2px rgba(0, 0, 0, 0.14);
}
 i{
   padding: 10px;
   color: #b4d2f0;
   
 }

 .like{
     display: flex;
     align-content: flex-start;
     left: 20px;
 }

</style>
